<?php
$nom = "Enrique";
$cognoms = "Iranzo Martínez";
$edat = "20";
$numero = "666666666";
$nom2 = "Alfredo";
$cognoms2 = "Pérez Gómez";
$edat2 = "33";
$numero2 = "636666666";



