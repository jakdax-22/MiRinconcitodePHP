<?php
$personas = array ("enrique", "ivan","alex","juan");
echo "El vector de cadenas recorriéndolo con FOREACH:<br>";
foreach ($personas as $numero )
{
    echo $numero ;
    echo "<br>";
}

