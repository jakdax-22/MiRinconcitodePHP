<?php
$elementos = array (10,20,30,40);

echo "<ul>Elemento 0 vale: " . $elementos [0] . "</ul>";
echo "<ul>Elemento 1 vale: " . $elementos [1] . "</ul>";
echo "<ul>Elemento 2 vale: " . $elementos [2] . "</ul>";
echo "<ul>Elemento 3 vale: " . $elementos [3] . "</ul>";