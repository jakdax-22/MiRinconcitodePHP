<?php
$hoy= getdate();
echo"<b>=========================<br>";
echo "Ahora son las: ";
echo "$hoy[hours] ";
echo "horas y ";
echo "$hoy[minutes] ";
echo "minutos <br>";
echo "==========================</b>"
?>