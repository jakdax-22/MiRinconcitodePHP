<?php
include "mediaValores.php";
include "mediaArray.php";
include "mediaValoresRefer.php";
$a=10;
$b=20;
$c=30;
echo media($a,$b,$c);
echo mediarray($a,$b,$c);
echo media2($a,$b,$media,2);