<?php
function producto ($num1,$num2)
{
echo "Se encuentra en el archivo:Funcionproducto.php<br>";
$prod=$num1*$num2;
echo "El resultado de $num1 y $num2 es $prod";
}

