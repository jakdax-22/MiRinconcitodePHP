<?php
include "libreriaProductos.php";
$a=10;
$b=20;
$c=30;
$d=40;
$e=50;
echo "Estamos en el programa principal<br><br>";
echo "<b>Producto</b><br>";
echo producto ($a,$b);
echo "<br><br>";
echo "<b>ProductoVarios</b><br>";
echo productoValores ($a,$b,$c,$d,$e);




