<?php
function suma ($num1,$num2)
{
$suma=$num1 + $num2;
echo "la suma de $num1 y $num2 es: $suma";
echo "<br><br>";
}
function producto ($num1,$num2)
{
$multi=$num1*$num2;
echo "El producto de $num1 y $num2 es: $multi";
echo "<br><br>";
}
