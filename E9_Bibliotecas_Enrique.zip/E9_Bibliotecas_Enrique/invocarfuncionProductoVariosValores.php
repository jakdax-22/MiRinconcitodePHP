<?php
include "funcionProductoVariosValores.php";
echo "<h2>Estamos en el programa principal</h2>";
echo "El valor de los parámetros lo establecemos desde él<br>";
$a=30;
$b=80;
$c=90;
$d=20;
echo "Hacemos la llamada a la funcion..<br><br>";
echo productoValores ($a,$b,$c,$d);
