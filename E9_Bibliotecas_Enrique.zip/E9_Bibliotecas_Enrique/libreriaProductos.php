<?php
include "Funcionproducto.php";
include "funcionProductoVariosValores.php";
