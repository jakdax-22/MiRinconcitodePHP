<?php
include "Funcionproducto.php";
echo "Asignamos valores a las variables<br><br>";
$a=10;
$b=20;
echo "multiplicando:$a<br>";
echo "multiplicador:$b<br><br>";
echo "Invocamos a la función<br>";
echo producto ($a,$b);
