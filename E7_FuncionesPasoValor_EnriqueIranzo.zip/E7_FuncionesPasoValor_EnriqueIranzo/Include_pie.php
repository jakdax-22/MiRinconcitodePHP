<?php
print "<h2>Página con include</h2>";
?>
Desarrollada por el alumno:
<?php
$nombre="Enrique";
$apellidos="Iranzo Martínez";
echo "<br>";
echo "<b>" . $nombre . " " . "$apellidos</b>";
?>
</body>
</html>
