<?php
function cabecera ($titulo)
{
print
    "<html>
        <head>
            <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">
             <title>$titulo</title>
        </head>
       <body>
          <h1>$titulo</h1>";
}
?>