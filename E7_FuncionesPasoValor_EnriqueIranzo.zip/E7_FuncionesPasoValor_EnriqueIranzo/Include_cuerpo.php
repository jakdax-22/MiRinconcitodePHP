<?php
include ("include_cabecera.php");
cabecera("Primeros pasos Funciones");
include ("include_pie.php");
?>

