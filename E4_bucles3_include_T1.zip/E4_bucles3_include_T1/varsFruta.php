<?php
$fruita = "manzana";
$Tamaño = "pequeño";
$color = "verde";
$posicion = "en la mesa";
?>


