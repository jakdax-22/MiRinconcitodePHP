<table border = "1" width = "500">
 "<th colspan="2"><center><b>DatosPersonales</b></th>";
<?php
include ("datPersonales.php");
echo "<tr><td><center>Nombre</center></td>";
echo "<td><center>$nom</center></td></tr>";
echo "<tr><td><center>Apellidos</center></td>";
echo "<td><center> $cognoms </center></td></tr>";
echo "<tr><td><center>Edad</center></td>";
echo "<td><center>$edat</center></td></tr>";
echo "<tr><td><center>Tlf Móvil</center></td>";
echo "<td><center>$numero</center></td></tr>";
?>
 "<th colspan="2"><center><b>===========</b></th>";    
<?php
echo "<tr><td><center>Nombre 2</center></td>";
echo "<td><center>$nom2</center></td></tr>";
echo "<tr><td><center>Apellidos 2</center></td>";
echo "<td><center> $cognoms2 </center></td></tr>";
echo "<tr><td><center>Edad 2</center></td>";
echo "<td><center>$edat2</center></td></tr>";
echo "<tr><td><center>Tlf Móvil 2</center></td>";
echo "<td><center>$numero2</center></td></tr>";

?>
     "<th colspan="2"><center><b>===========</b></th>";
     </table>

