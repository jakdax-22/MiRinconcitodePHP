<?php
echo "<h2>Archivo Header</h2>";
include ("CompraArticulosHeader.php");
echo "<br><br><h2>Archivo Footer</h2><br><br>";
include ("CompraArticulosFooter.php");