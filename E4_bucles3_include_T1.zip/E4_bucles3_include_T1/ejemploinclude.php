<?php
include ("capçalera.inc.html");

echo "Hola";

include ("peu.inc.html");
?>

