<table border = "1" width = "500">
 "<th colspan="2"><center><b>DatosPersonales</b></th>";
<?php
include ("datPersonales.php");
echo "<tr><td><center>Nombre</center></td>";
echo "<td><center>$nom</center></td></tr>";
echo "<tr><td><center>Apellidos</center></td>";
echo "<td><center> $cognoms </center></td></tr>";
echo "<tr><td><center>Edad</center></td>";
echo "<td><center>$edat</center></td></tr>";
echo "<tr><td><center>Tlf Móvil</center></td>";
echo "<td><center>$numero</center></td></tr>";
?>
</table>

