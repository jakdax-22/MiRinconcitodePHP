<?php
include 'funcionPotenciaRecursiva.php';
echo "Asignamos valores a los dos valores <br>";
$a=3;
$b=4;
echo '$a=3<br>';
echo '$b=4<br><br>';
echo "LLamada a Funcion <b>Potencia Recursiva</b><br>";
echo "$a elevado a $b es " . PotenciaRec($a, $b);

